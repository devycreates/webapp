"use client"
import { useParams } from "next/navigation"

// Game URLs (in a real implementation, these would be actual game URLs)
const gameUrls: Record<string, string> = {
  "1": "https://example.com/games/slope",
  "2": "https://example.com/games/2048",
  "3": "https://example.com/games/subway-surfers",
  "4": "https://example.com/games/flappy-bird",
  "5": "https://example.com/games/minecraft-classic",
  "6": "https://example.com/games/tetris",
  "7": "https://example.com/games/snake",
  "8": "https://example.com/games/pacman",
  "9": "https://example.com/games/crossy-road",
  "10": "https://example.com/games/geometry-dash",
  "11": "https://example.com/games/run-3",
  "12": "https://example.com/games/happy-wheels",
}

export default function GamePage() {
  const params = useParams()
  const id = params.id as string

  // For demonstration purposes, we'll just show a placeholder
  // In a real implementation, this would embed the actual game
  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-md max-w-md w-full text-center">
        <h1 className="text-2xl font-bold mb-4">Game {id}</h1>
        <p className="mb-4">This is where the game would be embedded.</p>
        <p className="text-sm text-gray-500">
          In a real implementation, this page would contain the actual game content.
        </p>
      </div>
    </div>
  )
}

