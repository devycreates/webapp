import Link from "next/link"
import { Calculator } from "lucide-react"

export default function PrivacyPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Calculator className="h-6 w-6 text-blue-600" />
            <h1 className="text-xl font-bold">MathLearningPortal</h1>
          </div>
          <nav className="hidden md:flex space-x-6">
            <Link href="/" className="font-medium">
              Home
            </Link>
            <Link href="/lessons" className="font-medium">
              Lessons
            </Link>
            <Link href="/practice" className="font-medium">
              Practice
            </Link>
            <Link href="/quizzes" className="font-medium">
              Quizzes
            </Link>
            <Link href="/quiz-center" className="font-medium">
              Quiz Center
            </Link>
            <Link href="/resources" className="font-medium">
              Resources
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-8 bg-blue-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-4">Privacy Policy</h2>
            <p className="text-lg mb-0 max-w-2xl">
              Your privacy is important to us. This policy outlines how we collect, use, and protect your information.
            </p>
          </div>
        </section>

        <section className="py-12 container mx-auto px-4">
          <div className="max-w-3xl mx-auto space-y-6">
            <h3 className="text-xl font-semibold">1. Information We Collect</h3>
            <p>
              We collect information you provide directly to us, such as when you create an account, subscribe to our
              newsletter, or contact us for support. This may include your name, email address, and any other
              information you choose to provide.
            </p>

            <h3 className="text-xl font-semibold">2. How We Use Your Information</h3>
            <p>
              We use the information we collect to provide, maintain, and improve our services, to communicate with you,
              and to personalize your learning experience.
            </p>

            <h3 className="text-xl font-semibold">3. Information Sharing and Disclosure</h3>
            <p>
              We do not share your personal information with third parties except as described in this policy. We may
              share information with service providers who perform services on our behalf, or when required by law.
            </p>

            <h3 className="text-xl font-semibold">4. Data Security</h3>
            <p>
              We take reasonable measures to help protect your personal information from loss, theft, misuse,
              unauthorized access, disclosure, alteration, and destruction.
            </p>

            <h3 className="text-xl font-semibold">5. Your Choices</h3>
            <p>
              You may update, correct, or delete your account information at any time by logging into your account or by
              contacting us. You may also opt out of receiving promotional communications from us by following the
              instructions in those communications.
            </p>

            <h3 className="text-xl font-semibold">6. Changes to This Policy</h3>
            <p>
              We may update this privacy policy from time to time. We will notify you of any changes by posting the new
              privacy policy on this page.
            </p>

            <h3 className="text-xl font-semibold">7. Contact Us</h3>
            <p>
              If you have any questions about this privacy policy, please contact us at privacy@mathlearningportal.com.
            </p>
          </div>
        </section>
      </main>

      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between">
            <div className="mb-6 md:mb-0">
              <div className="flex items-center space-x-2 mb-4">
                <Calculator className="h-6 w-6" />
                <h2 className="text-xl font-bold">MathLearningPortal</h2>
              </div>
              <p className="text-gray-400 max-w-md">
                Helping students master mathematics through interactive learning and practice.
              </p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
              <div>
                <h3 className="text-lg font-semibold mb-4">Learn</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/lessons" className="text-gray-400 hover:text-white">
                      Lessons
                    </Link>
                  </li>
                  <li>
                    <Link href="/practice" className="text-gray-400 hover:text-white">
                      Practice
                    </Link>
                  </li>
                  <li>
                    <Link href="/quizzes" className="text-gray-400 hover:text-white">
                      Quizzes
                    </Link>
                  </li>
                  <li>
                    <Link href="/quiz-center" className="text-gray-400 hover:text-white">
                      Quiz Center
                    </Link>
                  </li>
                  <li>
                    <Link href="/resources" className="text-gray-400 hover:text-white">
                      Resources
                    </Link>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">About</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/about" className="text-gray-400 hover:text-white">
                      Our Mission
                    </Link>
                  </li>
                  <li>
                    <Link href="/team" className="text-gray-400 hover:text-white">
                      Team
                    </Link>
                  </li>
                  <li>
                    <Link href="/contact" className="text-gray-400 hover:text-white">
                      Contact
                    </Link>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">Legal</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/terms" className="text-gray-400 hover:text-white">
                      Terms
                    </Link>
                  </li>
                  <li>
                    <Link href="/privacy" className="text-gray-400 hover:text-white">
                      Privacy
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-700 text-center text-gray-400">
            <p>© {new Date().getFullYear()} MathLearningPortal. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

