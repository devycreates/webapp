"use client"

import Link from "next/link"
import { Calculator, BookOpen, Video, FileText, Globe } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { motion } from "framer-motion"

const resources = [
  {
    title: "Textbooks",
    icon: BookOpen,
    items: [
      { name: "Elementary Algebra", link: "/resources/textbooks/elementary-algebra" },
      { name: "Precalculus", link: "/resources/textbooks/precalculus" },
      { name: "Calculus: Early Transcendentals", link: "/resources/textbooks/calculus" },
      { name: "Linear Algebra and Its Applications", link: "/resources/textbooks/linear-algebra" },
    ],
  },
  {
    title: "Video Tutorials",
    icon: Video,
    items: [
      { name: "Khan Academy Math", link: "https://www.khanacademy.org/math" },
      { name: "PatrickJMT", link: "https://patrickjmt.com/" },
      { name: "3Blue1Brown", link: "https://www.3blue1brown.com/" },
      { name: "MathBFF", link: "https://www.youtube.com/c/MathBFF" },
    ],
  },
  {
    title: "Practice Worksheets",
    icon: FileText,
    items: [
      { name: "Algebra Worksheets", link: "/resources/worksheets/algebra" },
      { name: "Geometry Worksheets", link: "/resources/worksheets/geometry" },
      { name: "Trigonometry Worksheets", link: "/resources/worksheets/trigonometry" },
      { name: "Calculus Worksheets", link: "/resources/worksheets/calculus" },
    ],
  },
  {
    title: "Online Tools",
    icon: Globe,
    items: [
      { name: "Desmos Graphing Calculator", link: "https://www.desmos.com/calculator" },
      { name: "Wolfram Alpha", link: "https://www.wolframalpha.com/" },
      { name: "GeoGebra", link: "https://www.geogebra.org/" },
      { name: "Symbolab", link: "https://www.symbolab.com/" },
    ],
  },
  {
    title: "Math Journals",
    icon: BookOpen,
    items: [
      {
        name: "The American Mathematical Monthly",
        link: "https://www.maa.org/press/periodicals/american-mathematical-monthly",
      },
      { name: "Mathematics Magazine", link: "https://www.maa.org/press/periodicals/mathematics-magazine" },
      {
        name: "The College Mathematics Journal",
        link: "https://www.maa.org/press/periodicals/college-mathematics-journal",
      },
      { name: "Math Horizons", link: "https://www.maa.org/press/periodicals/math-horizons" },
    ],
  },
  {
    title: "Math Communities",
    icon: Globe,
    items: [
      { name: "Math Stack Exchange", link: "https://math.stackexchange.com/" },
      { name: "Reddit r/math", link: "https://www.reddit.com/r/math/" },
      { name: "Art of Problem Solving", link: "https://artofproblemsolving.com/community" },
      { name: "MathOverflow", link: "https://mathoverflow.net/" },
    ],
  },
]

export default function ResourcesPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Calculator className="h-6 w-6 text-blue-600" />
            <h1 className="text-xl font-bold">MathLearningPortal</h1>
          </div>
          <nav className="hidden md:flex space-x-6">
            <Link href="/" className="font-medium">
              Home
            </Link>
            <Link href="/lessons" className="font-medium">
              Lessons
            </Link>
            <Link href="/practice" className="font-medium">
              Practice
            </Link>
            <Link href="/quizzes" className="font-medium">
              Quizzes
            </Link>
            <Link href="/resources" className="font-medium text-blue-600">
              Resources
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-12 bg-blue-600 text-white">
          <div className="container mx-auto px-4">
            <motion.h2
              className="text-4xl font-bold mb-4"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Math Resources
            </motion.h2>
            <motion.p
              className="text-xl mb-0 max-w-2xl"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              Explore our curated collection of math resources to support your learning journey.
            </motion.p>
          </div>
        </section>

        <section className="py-12 container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {resources.map((resource, index) => (
              <motion.div
                key={resource.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="h-full">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <resource.icon className="h-5 w-5 mr-2" />
                      {resource.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {resource.items.map((item) => (
                        <li key={item.name}>
                          <Link href={item.link} className="text-blue-600 hover:underline">
                            {item.name}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </section>
      </main>

      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p>© {new Date().getFullYear()} MathLearningPortal. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

