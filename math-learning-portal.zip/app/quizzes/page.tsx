"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Calculator, ChevronRight, Gamepad2 } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"

const quizzes = [
  {
    id: 1,
    title: "Algebra Basics",
    description: "Test your knowledge of basic algebraic concepts",
    questions: [
      {
        id: 1,
        question: "What is the value of x in the equation 2x + 5 = 13?",
        options: ["3", "4", "5", "6"],
        correctAnswer: "4",
      },
      {
        id: 2,
        question: "Which of the following is a linear equation?",
        options: ["y = x^2 + 3", "y = 2x + 1", "y = 1/x", "y = √x"],
        correctAnswer: "y = 2x + 1",
      },
      {
        id: 3,
        question: "What is the slope of the line y = 3x - 2?",
        options: ["1", "2", "3", "-2"],
        correctAnswer: "3",
      },
    ],
  },
  {
    id: 2,
    title: "Geometry Fundamentals",
    description: "Basic concepts in geometry",
    questions: [
      {
        id: 1,
        question: "What is the sum of angles in a triangle?",
        options: ["90°", "180°", "270°", "360°"],
        correctAnswer: "180°",
      },
      {
        id: 2,
        question: "Which shape has all sides equal and all angles equal to 90°?",
        options: ["Rectangle", "Rhombus", "Square", "Trapezoid"],
        correctAnswer: "Square",
      },
      {
        id: 3,
        question: "What is the formula for the area of a circle?",
        options: ["πr", "2πr", "πr^2", "2πr^2"],
        correctAnswer: "πr^2",
      },
    ],
  },
]

export default function QuizzesPage() {
  const [activeQuiz, setActiveQuiz] = useState<number | null>(null)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [quizSubmitted, setQuizSubmitted] = useState(false)

  const handleAnswerChange = (questionId: number, answer: string) => {
    setAnswers((prev) => ({ ...prev, [questionId]: answer }))
  }

  const handleQuizSubmit = () => {
    setQuizSubmitted(true)
  }

  const calculateScore = () => {
    if (!activeQuiz) return 0
    const quiz = quizzes.find((q) => q.id === activeQuiz)
    if (!quiz) return 0
    const correctAnswers = quiz.questions.filter((q) => answers[q.id] === q.correctAnswer)
    return (correctAnswers.length / quiz.questions.length) * 100
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Calculator className="h-6 w-6 text-blue-600" />
            <h1 className="text-xl font-bold">MathLearningPortal</h1>
          </div>
          <nav className="hidden md:flex space-x-6">
            <Link href="/" className="font-medium">
              Home
            </Link>
            <Link href="/lessons" className="font-medium">
              Lessons
            </Link>
            <Link href="/practice" className="font-medium">
              Practice
            </Link>
            <Link href="/quizzes" className="font-medium text-blue-600">
              Quizzes
            </Link>
            <Link href="/resources" className="font-medium">
              Resources
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-8 bg-blue-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-4">Math Quizzes</h2>
            <p className="text-lg mb-0 max-w-2xl">
              Test your knowledge with our collection of math quizzes on various topics.
            </p>
          </div>
        </section>

        <section className="py-12 container mx-auto px-4">
          {activeQuiz ? (
            <div>
              <h3 className="text-2xl font-bold mb-6">{quizzes.find((q) => q.id === activeQuiz)?.title}</h3>
              {quizzes
                .find((q) => q.id === activeQuiz)
                ?.questions.map((question) => (
                  <Card key={question.id} className="mb-6">
                    <CardHeader>
                      <CardTitle>{question.question}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <RadioGroup
                        onValueChange={(value) => handleAnswerChange(question.id, value)}
                        value={answers[question.id]}
                      >
                        {question.options.map((option, index) => (
                          <div key={index} className="flex items-center space-x-2">
                            <RadioGroupItem value={option} id={`q${question.id}-option${index}`} />
                            <Label htmlFor={`q${question.id}-option${index}`}>{option}</Label>
                          </div>
                        ))}
                      </RadioGroup>
                      {quizSubmitted && (
                        <div
                          className={`mt-4 p-2 rounded ${answers[question.id] === question.correctAnswer ? "bg-green-100" : "bg-red-100"}`}
                        >
                          {answers[question.id] === question.correctAnswer ? (
                            <p className="text-green-700">Correct!</p>
                          ) : (
                            <p className="text-red-700">Incorrect. The correct answer is: {question.correctAnswer}</p>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              {!quizSubmitted ? (
                <Button onClick={handleQuizSubmit}>Submit Quiz</Button>
              ) : (
                <div className="mt-6">
                  <h4 className="text-xl font-bold mb-2">Quiz Results</h4>
                  <p>Your score: {calculateScore().toFixed(2)}%</p>
                  <Button
                    onClick={() => {
                      setActiveQuiz(null)
                      setQuizSubmitted(false)
                      setAnswers({})
                    }}
                    className="mt-4"
                  >
                    Back to Quizzes
                  </Button>
                </div>
              )}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 gap-6">
              {quizzes.map((quiz) => (
                <Card key={quiz.id} className="overflow-hidden hover:shadow-md transition-shadow">
                  <CardHeader>
                    <CardTitle>{quiz.title}</CardTitle>
                    <CardDescription>{quiz.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="mb-4">{quiz.questions.length} questions</p>
                    <Button onClick={() => setActiveQuiz(quiz.id)}>
                      Start Quiz
                      <ChevronRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </section>
      </main>

      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between">
            <div className="mb-6 md:mb-0">
              <div className="flex items-center space-x-2 mb-4">
                <Calculator className="h-6 w-6" />
                <h2 className="text-xl font-bold">MathLearningPortal</h2>
              </div>
              <p className="text-gray-400 max-w-md">
                Helping students master mathematics through interactive learning and practice.
              </p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
              <div>
                <h3 className="text-lg font-semibold mb-4">Learn</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/lessons" className="text-gray-400 hover:text-white">
                      Lessons
                    </Link>
                  </li>
                  <li>
                    <Link href="/practice" className="text-gray-400 hover:text-white">
                      Practice
                    </Link>
                  </li>
                  <li>
                    <Link href="/quizzes" className="text-gray-400 hover:text-white">
                      Quizzes
                    </Link>
                  </li>
                  <li>
                    <Link href="/resources" className="text-gray-400 hover:text-white">
                      Resources
                    </Link>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">About</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/about" className="text-gray-400 hover:text-white">
                      Our Mission
                    </Link>
                  </li>
                  <li>
                    <Link href="/team" className="text-gray-400 hover:text-white">
                      Team
                    </Link>
                  </li>
                  <li>
                    <Link href="/contact" className="text-gray-400 hover:text-white">
                      Contact
                    </Link>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">Legal</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/terms" className="text-gray-400 hover:text-white">
                      Terms
                    </Link>
                  </li>
                  <li>
                    <Link href="/privacy" className="text-gray-400 hover:text-white">
                      Privacy
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-700 text-center text-gray-400">
            <p>© {new Date().getFullYear()} MathLearningPortal. All rights reserved.</p>
            <div className="mt-2 flex justify-center">
              <Link href="/fun" className="text-gray-500 hover:text-gray-300 text-xs flex items-center">
                <Gamepad2 className="h-3 w-3 mr-1" />
                <span>Brain Breaks</span>
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

