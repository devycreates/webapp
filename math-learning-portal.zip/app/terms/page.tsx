import Link from "next/link"
import { Calculator } from "lucide-react"

export default function TermsPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Calculator className="h-6 w-6 text-blue-600" />
            <h1 className="text-xl font-bold">MathLearningPortal</h1>
          </div>
          <nav className="hidden md:flex space-x-6">
            <Link href="/" className="font-medium">
              Home
            </Link>
            <Link href="/lessons" className="font-medium">
              Lessons
            </Link>
            <Link href="/practice" className="font-medium">
              Practice
            </Link>
            <Link href="/quizzes" className="font-medium">
              Quizzes
            </Link>
            <Link href="/quiz-center" className="font-medium">
              Quiz Center
            </Link>
            <Link href="/resources" className="font-medium">
              Resources
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-8 bg-blue-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-4">Terms of Service</h2>
            <p className="text-lg mb-0 max-w-2xl">Please read these terms carefully before using our service.</p>
          </div>
        </section>

        <section className="py-12 container mx-auto px-4">
          <div className="max-w-3xl mx-auto space-y-6">
            <h3 className="text-xl font-semibold">1. Acceptance of Terms</h3>
            <p>
              By accessing or using the MathLearningPortal service, you agree to be bound by these Terms of Service. If
              you do not agree to these terms, please do not use our service.
            </p>

            <h3 className="text-xl font-semibold">2. Description of Service</h3>
            <p>
              MathLearningPortal provides online mathematics education services, including lessons, practice problems,
              quizzes, and educational resources.
            </p>

            <h3 className="text-xl font-semibold">3. User Accounts</h3>
            <p>
              You may be required to create an account to access certain features of our service. You are responsible
              for maintaining the confidentiality of your account information and for all activities that occur under
              your account.
            </p>

            <h3 className="text-xl font-semibold">4. User Conduct</h3>
            <p>
              You agree to use the service only for lawful purposes and in accordance with these Terms of Service. You
              agree not to engage in any activity that interferes with or disrupts the service or its associated servers
              and networks.
            </p>

            <h3 className="text-xl font-semibold">5. Intellectual Property</h3>
            <p>
              All content on MathLearningPortal, including text, graphics, logos, and software, is the property of
              MathLearningPortal or its content suppliers and is protected by copyright laws.
            </p>

            <h3 className="text-xl font-semibold">6. Limitation of Liability</h3>
            <p>
              MathLearningPortal shall not be liable for any indirect, incidental, special, consequential, or punitive
              damages resulting from your access to or use of, or inability to access or use, the service.
            </p>

            <h3 className="text-xl font-semibold">7. Changes to Terms</h3>
            <p>
              We reserve the right to modify these Terms of Service at any time. We will provide notice of any material
              changes by posting the new Terms of Service on this page.
            </p>

            <h3 className="text-xl font-semibold">8. Contact Information</h3>
            <p>
              If you have any questions about these Terms of Service, please contact us at
              support@mathlearningportal.com.
            </p>
          </div>
        </section>
      </main>

      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between">
            <div className="mb-6 md:mb-0">
              <div className="flex items-center space-x-2 mb-4">
                <Calculator className="h-6 w-6" />
                <h2 className="text-xl font-bold">MathLearningPortal</h2>
              </div>
              <p className="text-gray-400 max-w-md">
                Helping students master mathematics through interactive learning and practice.
              </p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
              <div>
                <h3 className="text-lg font-semibold mb-4">Learn</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/lessons" className="text-gray-400 hover:text-white">
                      Lessons
                    </Link>
                  </li>
                  <li>
                    <Link href="/practice" className="text-gray-400 hover:text-white">
                      Practice
                    </Link>
                  </li>
                  <li>
                    <Link href="/quizzes" className="text-gray-400 hover:text-white">
                      Quizzes
                    </Link>
                  </li>
                  <li>
                    <Link href="/quiz-center" className="text-gray-400 hover:text-white">
                      Quiz Center
                    </Link>
                  </li>
                  <li>
                    <Link href="/resources" className="text-gray-400 hover:text-white">
                      Resources
                    </Link>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">About</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/about" className="text-gray-400 hover:text-white">
                      Our Mission
                    </Link>
                  </li>
                  <li>
                    <Link href="/team" className="text-gray-400 hover:text-white">
                      Team
                    </Link>
                  </li>
                  <li>
                    <Link href="/contact" className="text-gray-400 hover:text-white">
                      Contact
                    </Link>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">Legal</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/terms" className="text-gray-400 hover:text-white">
                      Terms
                    </Link>
                  </li>
                  <li>
                    <Link href="/privacy" className="text-gray-400 hover:text-white">
                      Privacy
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-700 text-center text-gray-400">
            <p>© {new Date().getFullYear()} MathLearningPortal. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

