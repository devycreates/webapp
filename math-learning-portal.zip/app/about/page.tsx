import Link from "next/link"
import { Calculator } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Calculator className="h-6 w-6 text-blue-600" />
            <h1 className="text-xl font-bold">MathLearningPortal</h1>
          </div>
          <nav className="hidden md:flex space-x-6">
            <Link href="/" className="font-medium">
              Home
            </Link>
            <Link href="/lessons" className="font-medium">
              Lessons
            </Link>
            <Link href="/practice" className="font-medium">
              Practice
            </Link>
            <Link href="/quizzes" className="font-medium">
              Quizzes
            </Link>
            <Link href="/quiz-center" className="font-medium">
              Quiz Center
            </Link>
            <Link href="/resources" className="font-medium">
              Resources
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-8 bg-blue-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-4">Our Mission</h2>
            <p className="text-lg mb-0 max-w-2xl">
              Empowering students to excel in mathematics through innovative learning solutions.
            </p>
          </div>
        </section>

        <section className="py-12 container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <p className="mb-6">
              At MathLearningPortal, our mission is to make mathematics accessible, engaging, and enjoyable for students
              of all ages and skill levels. We believe that a strong foundation in mathematics is crucial for success in
              many aspects of life, and we are committed to providing the tools and resources necessary for students to
              build that foundation.
            </p>
            <p className="mb-6">Our goals are to:</p>
            <ul className="list-disc pl-8 mb-6 space-y-2">
              <li>Provide high-quality, interactive math lessons that cater to various learning styles</li>
              <li>Offer a wide range of practice problems and quizzes to reinforce learning</li>
              <li>Create a supportive community where students can collaborate and learn from each other</li>
              <li>Continuously update our content to align with current educational standards and best practices</li>
              <li>
                Make advanced mathematical concepts more approachable through clear explanations and visualizations
              </li>
            </ul>
            <p className="mb-6">We strive to break down barriers to mathematical understanding by offering:</p>
            <ul className="list-disc pl-8 mb-6 space-y-2">
              <li>Personalized learning paths that adapt to each student's progress</li>
              <li>Immediate feedback on practice problems and quizzes</li>
              <li>
                A variety of resources including video tutorials, interactive simulations, and downloadable materials
              </li>
              <li>Tools to track progress and identify areas for improvement</li>
            </ul>
            <p>
              By fostering a love for mathematics and building confidence in problem-solving skills, we aim to prepare
              students for success in their academic pursuits and beyond. Join us on this exciting journey of
              mathematical discovery and growth!
            </p>
          </div>
        </section>
      </main>

      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between">
            <div className="mb-6 md:mb-0">
              <div className="flex items-center space-x-2 mb-4">
                <Calculator className="h-6 w-6" />
                <h2 className="text-xl font-bold">MathLearningPortal</h2>
              </div>
              <p className="text-gray-400 max-w-md">
                Helping students master mathematics through interactive learning and practice.
              </p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
              <div>
                <h3 className="text-lg font-semibold mb-4">Learn</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/lessons" className="text-gray-400 hover:text-white">
                      Lessons
                    </Link>
                  </li>
                  <li>
                    <Link href="/practice" className="text-gray-400 hover:text-white">
                      Practice
                    </Link>
                  </li>
                  <li>
                    <Link href="/quizzes" className="text-gray-400 hover:text-white">
                      Quizzes
                    </Link>
                  </li>
                  <li>
                    <Link href="/quiz-center" className="text-gray-400 hover:text-white">
                      Quiz Center
                    </Link>
                  </li>
                  <li>
                    <Link href="/resources" className="text-gray-400 hover:text-white">
                      Resources
                    </Link>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">About</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/about" className="text-gray-400 hover:text-white">
                      Our Mission
                    </Link>
                  </li>
                  <li>
                    <Link href="/team" className="text-gray-400 hover:text-white">
                      Team
                    </Link>
                  </li>
                  <li>
                    <Link href="/contact" className="text-gray-400 hover:text-white">
                      Contact
                    </Link>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">Legal</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/terms" className="text-gray-400 hover:text-white">
                      Terms
                    </Link>
                  </li>
                  <li>
                    <Link href="/privacy" className="text-gray-400 hover:text-white">
                      Privacy
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-700 text-center text-gray-400">
            <p>© {new Date().getFullYear()} MathLearningPortal. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

