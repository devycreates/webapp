"use client"

import { useState } from "react"
import Link from "next/link"
import { Input } from "@/components/ui/input"
import { Calculator, Search, ArrowLeft } from "lucide-react"

// Game data
const games = [
  {
    id: 1,
    title: "Slope",
    description: "Race down a slope avoiding obstacles",
    image: "/placeholder.svg?height=150&width=250",
  },
  { id: 2, title: "2048", description: "Merge tiles to reach 2048", image: "/placeholder.svg?height=150&width=250" },
  {
    id: 3,
    title: "Subway Surfers",
    description: "Endless runner game",
    image: "/placeholder.svg?height=150&width=250",
  },
  {
    id: 4,
    title: "Flappy Bird",
    description: "Navigate through pipes",
    image: "/placeholder.svg?height=150&width=250",
  },
  {
    id: 5,
    title: "Minecraft Classic",
    description: "Build and explore",
    image: "/placeholder.svg?height=150&width=250",
  },
  {
    id: 6,
    title: "Tetris",
    description: "Classic block stacking game",
    image: "/placeholder.svg?height=150&width=250",
  },
  {
    id: 7,
    title: "Snake",
    description: "Grow your snake by eating food",
    image: "/placeholder.svg?height=150&width=250",
  },
  { id: 8, title: "Pacman", description: "Eat dots and avoid ghosts", image: "/placeholder.svg?height=150&width=250" },
  {
    id: 9,
    title: "Crossy Road",
    description: "Cross busy roads and rivers",
    image: "/placeholder.svg?height=150&width=250",
  },
  {
    id: 10,
    title: "Geometry Dash",
    description: "Rhythm-based platformer",
    image: "/placeholder.svg?height=150&width=250",
  },
  { id: 11, title: "Run 3", description: "Run through space tunnels", image: "/placeholder.svg?height=150&width=250" },
  {
    id: 12,
    title: "Happy Wheels",
    description: "Ragdoll physics game",
    image: "/placeholder.svg?height=150&width=250",
  },
]

export default function SecretPage() {
  const [searchTerm, setSearchTerm] = useState("")

  // Filter games based on search term
  const filteredGames = games.filter((game) => game.title.toLowerCase().includes(searchTerm.toLowerCase()))

  // Function to open game in about:blank
  const openGameInBlank = (gameId: number) => {
    // In a real implementation, this would point to the actual game URL
    const gameUrl = `/games/${gameId}`

    // Create a blank window
    const newWindow = window.open("about:blank", "_blank")

    if (newWindow) {
      // Write content to the blank window that loads the game
      newWindow.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>Math Exercise</title>
            <style>
              body, html { margin: 0; padding: 0; height: 100%; overflow: hidden; }
              iframe { width: 100%; height: 100%; border: none; }
            </style>
          </head>
          <body>
            <iframe src="${gameUrl}" allowfullscreen></iframe>
          </body>
        </html>
      `)
      newWindow.document.close()
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Calculator className="h-6 w-6 text-blue-600" />
            <h1 className="text-xl font-bold">MathLearningPortal</h1>
          </div>
          <Link href="/" className="flex items-center text-blue-600 hover:text-blue-800">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to Math
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-sm border p-6 mb-8">
          <h2 className="text-2xl font-bold mb-4">Game Collection</h2>
          <p className="text-gray-600 mb-6">
            Welcome to our hidden game collection! Click on any game to play it in a separate window.
          </p>

          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              type="text"
              placeholder="Search games..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredGames.map((game) => (
              <div
                key={game.id}
                className="border rounded-lg overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => openGameInBlank(game.id)}
              >
                <img src={game.image || "/placeholder.svg"} alt={game.title} className="w-full h-40 object-cover" />
                <div className="p-4">
                  <h3 className="font-bold text-lg mb-1">{game.title}</h3>
                  <p className="text-gray-600 text-sm">{game.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      <footer className="bg-white border-t py-6">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>© {new Date().getFullYear()} MathLearningPortal. All rights reserved.</p>
          <p className="text-sm mt-2">This page is for educational purposes only.</p>
        </div>
      </footer>
    </div>
  )
}

