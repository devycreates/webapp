"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Calculator, CheckCircle, X } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

// Function to generate random math problems
const generateProblem = () => {
  const operations = ["+", "-", "*", "/"]
  const operation = operations[Math.floor(Math.random() * operations.length)]
  let num1, num2

  switch (operation) {
    case "+":
    case "-":
      num1 = Math.floor(Math.random() * 100)
      num2 = Math.floor(Math.random() * 100)
      break
    case "*":
      num1 = Math.floor(Math.random() * 12)
      num2 = Math.floor(Math.random() * 12)
      break
    case "/":
      num2 = Math.floor(Math.random() * 11) + 1 // Divisor between 1 and 12
      num1 = num2 * Math.floor(Math.random() * 12) // Ensure division results in whole number
      break
  }

  const question = `${num1} ${operation} ${num2}`
  const answer = eval(question).toString() // Evaluate the expression

  return { question, answer }
}

export default function QuizCenterPage() {
  const [problem, setProblem] = useState({ question: "", answer: "" })
  const [userAnswer, setUserAnswer] = useState("")
  const [result, setResult] = useState<"correct" | "incorrect" | null>(null)
  const [streak, setStreak] = useState(0)

  useEffect(() => {
    setProblem(generateProblem())
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (userAnswer === problem.answer) {
      setResult("correct")
      setStreak(streak + 1)
      setProblem(generateProblem())
    } else {
      setResult("incorrect")
      setStreak(0)
    }
    setUserAnswer("")
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Calculator className="h-6 w-6 text-blue-600" />
            <h1 className="text-xl font-bold">MathLearningPortal</h1>
          </div>
          <nav className="hidden md:flex space-x-6">
            <Link href="/" className="font-medium">
              Home
            </Link>
            <Link href="/lessons" className="font-medium">
              Lessons
            </Link>
            <Link href="/practice" className="font-medium">
              Practice
            </Link>
            <Link href="/quizzes" className="font-medium">
              Quizzes
            </Link>
            <Link href="/quiz-center" className="font-medium text-blue-600">
              Quiz Center
            </Link>
            <Link href="/resources" className="font-medium">
              Resources
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-8 bg-blue-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-4">Quiz Center</h2>
            <p className="text-lg mb-0 max-w-2xl">Test your math skills with infinite random problems!</p>
          </div>
        </section>

        <section className="py-12 container mx-auto px-4">
          <Card className="max-w-md mx-auto">
            <CardHeader>
              <CardTitle>Solve the Problem</CardTitle>
              <CardDescription>Current streak: {streak}</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="text-2xl font-bold text-center">{problem.question} = ?</div>
                <Input
                  type="text"
                  value={userAnswer}
                  onChange={(e) => setUserAnswer(e.target.value)}
                  placeholder="Enter your answer"
                />
                <Button type="submit" className="w-full">
                  Submit Answer
                </Button>
              </form>
              {result && (
                <div className={`mt-4 p-4 rounded-md ${result === "correct" ? "bg-green-100" : "bg-red-100"}`}>
                  {result === "correct" ? (
                    <div className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                      <span>Correct! Great job!</span>
                    </div>
                  ) : (
                    <div className="flex items-center">
                      <X className="h-5 w-5 text-red-600 mr-2" />
                      <span>Incorrect. The correct answer was {problem.answer}.</span>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </section>
      </main>

      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between">
            <div className="mb-6 md:mb-0">
              <div className="flex items-center space-x-2 mb-4">
                <Calculator className="h-6 w-6" />
                <h2 className="text-xl font-bold">MathLearningPortal</h2>
              </div>
              <p className="text-gray-400 max-w-md">
                Helping students master mathematics through interactive learning and practice.
              </p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
              <div>
                <h3 className="text-lg font-semibold mb-4">Learn</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/lessons" className="text-gray-400 hover:text-white">
                      Lessons
                    </Link>
                  </li>
                  <li>
                    <Link href="/practice" className="text-gray-400 hover:text-white">
                      Practice
                    </Link>
                  </li>
                  <li>
                    <Link href="/quizzes" className="text-gray-400 hover:text-white">
                      Quizzes
                    </Link>
                  </li>
                  <li>
                    <Link href="/quiz-center" className="text-gray-400 hover:text-white">
                      Quiz Center
                    </Link>
                  </li>
                  <li>
                    <Link href="/resources" className="text-gray-400 hover:text-white">
                      Resources
                    </Link>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">About</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/about" className="text-gray-400 hover:text-white">
                      Our Mission
                    </Link>
                  </li>
                  <li>
                    <Link href="/team" className="text-gray-400 hover:text-white">
                      Team
                    </Link>
                  </li>
                  <li>
                    <Link href="/contact" className="text-gray-400 hover:text-white">
                      Contact
                    </Link>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">Legal</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/terms" className="text-gray-400 hover:text-white">
                      Terms
                    </Link>
                  </li>
                  <li>
                    <Link href="/privacy" className="text-gray-400 hover:text-white">
                      Privacy
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-700 text-center text-gray-400">
            <p>© {new Date().getFullYear()} MathLearningPortal. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

