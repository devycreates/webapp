import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Calculator, ChevronRight, Gamepad2 } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function AlgebraLessonsPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Calculator className="h-6 w-6 text-blue-600" />
            <h1 className="text-xl font-bold">MathLearningPortal</h1>
          </div>
          <nav className="hidden md:flex space-x-6">
            <Link href="/" className="font-medium">
              Home
            </Link>
            <Link href="/lessons" className="font-medium text-blue-600">
              Lessons
            </Link>
            <Link href="/practice" className="font-medium">
              Practice
            </Link>
            <Link href="/quizzes" className="font-medium">
              Quizzes
            </Link>
            <Link href="/resources" className="font-medium">
              Resources
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-8 bg-blue-50">
          <div className="container mx-auto px-4">
            <div className="flex items-center gap-2 mb-2">
              <Link href="/lessons" className="text-blue-600 hover:underline">
                Lessons
              </Link>
              <ChevronRight className="h-4 w-4" />
              <span>Algebra</span>
            </div>
            <h2 className="text-3xl font-bold mb-4">Algebra Lessons</h2>
            <p className="text-lg mb-0 max-w-2xl">
              Master algebraic concepts from basic equations to advanced functions.
            </p>
          </div>
        </section>

        <section className="py-12 container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "Introduction to Algebra",
                description: "Learn the basic concepts and notation used in algebra.",
                level: "Beginner",
                duration: "20 min",
                link: "/lessons/algebra/introduction",
              },
              {
                title: "Linear Equations",
                description: "Solve equations of the form ax + b = c.",
                level: "Beginner",
                duration: "25 min",
                link: "/lessons/algebra/linear-equations",
              },
              {
                title: "Quadratic Equations",
                description: "Master equations of the form ax² + bx + c = 0.",
                level: "Intermediate",
                duration: "30 min",
                link: "/lessons/algebra/quadratic-equations",
              },
              {
                title: "Systems of Equations",
                description: "Solve multiple equations with multiple variables.",
                level: "Intermediate",
                duration: "35 min",
                link: "/lessons/algebra/systems",
              },
              {
                title: "Polynomials",
                description: "Work with expressions with variables raised to different powers.",
                level: "Intermediate",
                duration: "30 min",
                link: "/lessons/algebra/polynomials",
              },
              {
                title: "Factoring",
                description: "Break down expressions into simpler components.",
                level: "Intermediate",
                duration: "25 min",
                link: "/lessons/algebra/factoring",
              },
              {
                title: "Functions",
                description: "Understand the concept of functions and their properties.",
                level: "Advanced",
                duration: "40 min",
                link: "/lessons/algebra/functions",
              },
              {
                title: "Logarithms",
                description: "Learn about logarithmic functions and their applications.",
                level: "Advanced",
                duration: "35 min",
                link: "/lessons/algebra/logarithms",
              },
              {
                title: "Complex Numbers",
                description: "Work with numbers involving the imaginary unit i.",
                level: "Advanced",
                duration: "45 min",
                link: "/lessons/algebra/complex-numbers",
              },
            ].map((lesson, index) => (
              <Card key={index} className="overflow-hidden hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-center mb-1">
                    <span
                      className={`px-2 py-1 text-xs rounded ${
                        lesson.level === "Beginner"
                          ? "bg-green-100 text-green-800"
                          : lesson.level === "Intermediate"
                            ? "bg-blue-100 text-blue-800"
                            : "bg-purple-100 text-purple-800"
                      }`}
                    >
                      {lesson.level}
                    </span>
                    <span className="text-sm text-gray-500">{lesson.duration}</span>
                  </div>
                  <CardTitle>{lesson.title}</CardTitle>
                  <CardDescription>{lesson.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button variant="outline" className="w-full" asChild>
                    <Link href={lesson.link}>
                      Start Lesson
                      <ChevronRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </main>

      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between">
            <div className="mb-6 md:mb-0">
              <div className="flex items-center space-x-2 mb-4">
                <Calculator className="h-6 w-6" />
                <h2 className="text-xl font-bold">MathLearningPortal</h2>
              </div>
              <p className="text-gray-400 max-w-md">
                Helping students master mathematics through interactive learning and practice.
              </p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
              <div>
                <h3 className="text-lg font-semibold mb-4">Learn</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/lessons" className="text-gray-400 hover:text-white">
                      Lessons
                    </Link>
                  </li>
                  <li>
                    <Link href="/practice" className="text-gray-400 hover:text-white">
                      Practice
                    </Link>
                  </li>
                  <li>
                    <Link href="/quizzes" className="text-gray-400 hover:text-white">
                      Quizzes
                    </Link>
                  </li>
                  <li>
                    <Link href="/resources" className="text-gray-400 hover:text-white">
                      Resources
                    </Link>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">About</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/about" className="text-gray-400 hover:text-white">
                      Our Mission
                    </Link>
                  </li>
                  <li>
                    <Link href="/team" className="text-gray-400 hover:text-white">
                      Team
                    </Link>
                  </li>
                  <li>
                    <Link href="/contact" className="text-gray-400 hover:text-white">
                      Contact
                    </Link>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">Legal</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/terms" className="text-gray-400 hover:text-white">
                      Terms
                    </Link>
                  </li>
                  <li>
                    <Link href="/privacy" className="text-gray-400 hover:text-white">
                      Privacy
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-700 text-center text-gray-400">
            <p>© {new Date().getFullYear()} MathLearningPortal. All rights reserved.</p>
            <div className="mt-2 flex justify-center">
              <Link href="/fun" className="text-gray-500 hover:text-gray-300 text-xs flex items-center">
                <Gamepad2 className="h-3 w-3 mr-1" />
                <span>Brain Breaks</span>
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

