"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Calculator, ChevronRight, ChevronLeft, Gamepad2 } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function QuadraticEquationsLesson() {
  const [activeTab, setActiveTab] = useState("lesson")
  const [practiceAnswers, setPracticeAnswers] = useState<Record<string, string>>({})
  const [showSolutions, setShowSolutions] = useState(false)
  
  const checkAnswer = (questionId: string, correctAnswer: string) => {
    return showSolutions ? practiceAnswers[questionId] === correctAnswer : null
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Calculator className="h-6 w-6 text-blue-600" />
            <h1 className="text-xl font-bold">MathLearningPortal</h1>
          </div>
          <nav className="hidden md:flex space-x-6">
            <Link href="/" className="font-medium">Home</Link>
            <Link href="/lessons" className="font-medium text-blue-600">Lessons</Link>
            <Link href="/practice" className="font-medium">Practice</Link>
            <Link href="/quizzes" className="font-medium">Quizzes</Link>
            <Link href="/resources" className="font-medium">Resources</Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-8 bg-blue-50">
          <div className="container mx-auto px-4">
            <div className="flex items-center gap-2 mb-2">
              <Link href="/lessons" className="text-blue-600 hover:underline">Lessons</Link>
              <ChevronRight className="h-4 w-4" />
              <Link href="/lessons/algebra" className="text-blue-600 hover:underline">Algebra</Link>
              <ChevronRight className="h-4 w-4" />
              <span>Quadratic Equations</span>
            </div>
            <h2 className="text-3xl font-bold mb-4">Quadratic Equations</h2>
            <p className="text-lg mb-0 max-w-2xl">
              Learn how to solve equations of the form ax² + bx + c = 0.
            </p>
          </div>
        </section>

        <section className="py-8 container mx-auto px-4">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="lesson">Lesson</TabsTrigger>
              <TabsTrigger value="practice">Practice</TabsTrigger>
              <TabsTrigger value="quiz">Quiz</TabsTrigger>
            </TabsList>
            
            <TabsContent value="lesson" className="space-y-8">
              <Card>
                <CardContent className="pt-6">
                  <h3 className="text-xl font-bold mb-4">What is a Quadratic Equation?</h3>
                  <p className="mb-4">
                    A quadratic equation is a second-degree polynomial equation in a single variable x:
                  </p>
                  <div className="bg-gray-100 p-4 rounded-md text-center mb-4">
                    <p className="text-xl font-medium">ax² + bx + c = 0</p>
                  </div>
                  <p className="mb-4">
                    where a, b, and c are constants, and a ≠ 0 (otherwise, the equation becomes linear).
                  </p>
                  <h4 className="text-lg font-semibold mt-6 mb-2">Examples of Quadratic Equations:</h4>
                  <ul className="list-disc pl-6 space-y-2 mb-4">
                    <li>x² + 5x + 6 = 0</li>
                    <li>2x² - 7x + 3 = 0</li>
                    <li>-4x² + 2x + 1 = 0</li>
                  </ul>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <h3 className="text-xl font-bold mb-4">Solving Quadratic Equations</h3>
                  <p className="mb-4">
                    There are several methods to solve quadratic equations:
                  </p>
                  
                  <h4 className="text-lg font-semibold mt-6 mb-2">1. Factoring</h4>
                  <p className="mb-4">
                    If we can factor the quadratic expression, we can find the solutions easily:
                  </p>
                  <div className="bg-gray-100 p-4 rounded-md mb-4">
                    <p className="mb-2">Example: x² + 5x + 6 = 0</p>
                    <p className="mb-2">Step 1: Factor the expression: (x + 2)(x + 3) = 0</p>
                    <p className="mb-2">Step 2: Set each factor equal to zero:</p>
                    <p className="mb-1">x + 2 = 0 → x = -2</p>
                    <p>x + 3 = 0 → x = -3</p>
                  </div>
                  
                  <h4 className="text-lg font-semibold mt-6 mb-2">2. Quadratic Formula</h4>
                  <p className="mb-4">
                    For any quadratic equation ax² + bx + c = 0, the solutions are given by:
                  </p>
                  <div className="bg-gray-100 p-4 rounded-md text-center mb-4">
                    <p className="text-xl font-medium">x = (-b ± √(b² - 4ac)) / (2a)</p>
                  </div>
                  <p className="mb-4">
                    The expression b² - 4ac is called the discriminant. It tells us about the nature of the roots:
                  </p>
                  <ul className="list-disc pl-6 space-y-2 mb-4">
                    <li>If b² - 4ac > 0, there are two distinct real roots</li>
                    <li>If b² - 4ac = 0, there is one repeated real root</li>
                    <li>If b² - 4ac < 0, there are two complex conjugate roots</li>
                  </ul>
                  
                  <h4 className="text-lg font-semibold mt-6 mb-2">3. Completing the Square</h4>
                  <p className="mb-4">
                    This method involves rewriting the quadratic expression as a perfect square plus or minus a constant.
                  </p>
                </CardContent>
              </Card>
              
              <div className="flex justify-between">
                <Button variant="outline" asChild>
                  <Link href="/lessons/algebra/linear-equations">
                    <ChevronLeft className="mr-2 h-4 w-4" />
                    Previous: Linear Equations
                  </Link>
                </Button>
                <Button variant="outline" asChild>
                  <Link href="/lessons/algebra/systems">
                    Next: Systems of Equations
                    <ChevronRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="practice" className="space-y-8">
              <Card>
                <CardContent className="pt-6">
                  <h3 className="text-xl font-bold mb-4">Practice Problems</h3>
                  <p className="mb-6">
                    Solve the following quadratic equations. You can check your answers after attempting the problems.
                  </p>
                  
                  <div className="space-y-8">
                    <div className="border p-4 rounded-md">
                      <h4 className="font-semibold mb-2">Problem 1: Solve by factoring</h4>
                      <p className="mb-4">x² + 7x + 12 = 0</p>
                      <div className="mb-4">
                        <Label htmlFor="problem1">Your answer (separate roots with a comma):</Label>
                        <Input 
                          id="problem1" 
                          placeholder="e.g., -3, -4" 
                          className="mt-1"
                          value={practiceAnswers.problem1 || ''}
                          onChange={(e) => setPracticeAnswers({...practiceAnswers, problem1: e.target.value})}
                        />
                      </div>
                      {showSolutions && (
                        <div className={`p-3 rounded-md ${checkAnswer('problem1', '-3, -4') ? 'bg-green-100' : 'bg-red-100'}`}>
                          <p className="font-medium">Solution:</p>
                          <p>x² + 7x + 12 = 0</p>
                          <p>(x + 3)(x + 4) = 0</p>
                          <p>x = -3 or x = -4</p>
                        </div>
                      )}
                    </div>
                    
                    <div className="border p-4 rounded-md">
                      <h4 className="font-semibold mb-2">Problem 2: Solve using the quadratic formula</h4>
                      <p className="mb-4">2x² - 5x - 3 = 0</p>
                      <div className="mb-4">
                        <Label htmlFor="problem2">Your answer (separate roots with a comma):</Label>
                        <Input 
                          id="problem2" 
                          placeholder="e.g., 3, -0.5" 
                          className="mt-1"
                          value={practiceAnswers.problem2 || ''}
                          onChange={(e) => setPracticeAnswers({...practiceAnswers, problem2: e.target.value})}
                        />
                      </div>
                      {showSolutions && (
                        <div className={`p-3 rounded-md ${checkAnswer('problem2', '3, -0.5') ? 'bg-green-100' : 'bg-red-100'}`}>
                          <p className="font-medium">Solution:</p>
                          <p>Using the quadratic formula with a=2, b=-5, c=-3:</p>
                          <p>x = (5 ± √(25 + 24)) / 4</p>
                          <p>x = (5 ± √49) / 4</p>
                          <p>x = (5 ± 7) / 4</p>
                          <p>x = 3 or x = -0.5</p>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="mt-6 flex justify-center">
                    <Button onClick={() => setShowSolutions(!showSolutions)}>
                      {showSolutions ? 'Hide Solutions' : 'Check Answers'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="quiz" className="space-y-8">
              <Card>
                <CardContent className="pt-6">
                  <h3 className="text-xl font-bold mb-4">Quiz: Quadratic Equations</h3>
                  <p className="mb-6">
                    Test your understanding of quadratic equations with this short quiz.
                  </p>
                  
                  <div className="space-y-6">
                    <div className="border p-4 rounded-md">
                      <h4 className="font-semibold mb-2">Question 1:</h4>
                      <p className="mb-4">What is the discriminant of the quadratic equation 3x² - 2x - 1 = 0?</p>
                      <RadioGroup 
                        value={practiceAnswers.quiz1 || ''}
                        onValueChange={(value) => setPracticeAnswers({...practiceAnswers, quiz1: value})}
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="A" id="q1-a" />
                          <Label htmlFor="q1-a">A. 4</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="B" id="q1-b" />
                          <Label htmlFor="q1-b">B. 12</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="C" id="q1-c" />
                          <Label htmlFor="q1-c">C. 16</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="D" id="q1-d" />
                          <Label htmlFor="q1-d">D. 8</Label>
                        </div>
                      </RadioGroup>
                      {showSolutions && (
                        <div className={`mt-4 p-3 rounded-md ${checkAnswer('quiz1', 'B') ? 'bg-green-100' : 'bg-red-100'}`}>
                          <p className="font-medium">Correct Answer: B. 12</p>
                          <p>For 3x² - 2x - 1 = 0, we have a=3, b=-2, c=-1</p>
                          <p>Discriminant = b² - 4ac = (-2)² - 4(3)(-1) = 4 + 12 = 16</p>
                        </div>
                      )}
                    </div>
                    
                    <div className="border p-4 rounded-md">
                      <h4 className="font-semibold mb-2">Question 2:</h4>
                      <p className="mb-4">Which of the following quadratic equations has exactly one real solution?</p>
                      <RadioGroup 
                        value={practiceAnswers.quiz2 || ''}
                        onValueChange={(value) => setPracticeAnswers({...practiceAnswers, quiz2: value})}
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="A" id="q2-a" />
                          <Label htmlFor="q2-a">A. x² - 4x + 4 = 0</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="B" id="q2-b" />
                          <Label htmlFor="q2-b">B. x² - 5x + 6 = 0</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="C" id="q2-c" />
                          <Label htmlFor="q2-c">C. x² + x + 1 = 0</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="D" id="q2-d" />
                          <Label htmlFor="q2-d">D. 2x² - 3x - 2 = 0</Label>
                        </div>
                      </RadioGroup>
                      {showSolutions && (
                        <div className={`mt-4 p-3 rounded-md ${checkAnswer('quiz2', 'A') ? 'bg-green-100' : 'bg-red-100'}`}>
                          <p className="font-medium">Correct Answer: A. x² - 4x + 4 = 0</p>
                          <p>This can be factored as (x - 2)² = 0, which has exactly one solution: x = 2</p>
                          <p>The discriminant is b² - 4ac = (-4)² - 4(1)(4) = 16 - 16 = 0</p>
                          <p>When the discriminant is zero, there is exactly one real solution.</p>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="mt-6 flex justify-center">
                    <Button onClick={() => setShowSolutions(!showSolutions)}>
                      {showSolutions ? 'Hide Solutions' : 'Check Answers'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </section>
      </main>

      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between">
            <div className="mb-6 md:mb-0">
              <div className="flex items-center space-x-2 mb-4">
                <Calculator className="h-6 w-6" />
                <h2 className="text-xl font-bold">MathLearningPortal</h2>
              </div>
              <p className="text-gray-400 max-w-md">
                Helping students master mathematics through interactive learning and practice.
              </p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
              <div>
                <h3 className="text-lg font-semibold mb-4">Learn</h3>
                <ul className="space-y-2">
                  <li><Link href="/lessons" className="text-gray-400 hover:text-white">Lessons</Link></li>
                  <li><Link href="/practice" className="text-gray-400 hover:text-white">Practice</Link></li>
                  <li><Link href="/quizzes" className="text-gray-400 hover:text-white">Quizzes</Link></li>
                  <li><Link href="/resources" className="text-gray-400 hover:text-white">Resources</Link></li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">About</h3>
                <ul className="space-y-2">
                  <li><Link href="/about" className="text-gray-400 hover:text-white">Our Mission</Link></li>
                  <li><Link href="/team" className="text-gray-400 hover:text-white">Team</Link></li>
                  <li><Link href="/contact" className="text-gray-400 hover:text-white">Contact</Link></li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">Legal</h3>
                <ul className="space-y-2">
                  <li><Link href="/terms" className="text-gray-400 hover:text-white">Terms</Link></li>
                  <li><Link href="/privacy" className="text-gray-400 hover:text-white">Privacy</Link></li>
                </ul>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-700 text-center text-gray-400">
            <p>© {new Date().getFullYear()} MathLearningPortal. All rights reserved.</p>
            <div className="mt-2 flex justify-center">
              <Link href="/fun" className="text-gray-500 hover:text-gray-300 text-xs flex items-center">
                <Gamepad2 className="h-3 w-3 mr-1" />
                <span>Brain Breaks</span>
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

