"use client"

import Link from "next/link"
import { Calculator, ArrowLeft, ArrowRight } from "lucide-react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"

export default function AlgebraIntroductionPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Calculator className="h-6 w-6 text-blue-600" />
            <h1 className="text-xl font-bold">MathLearningPortal</h1>
          </div>
          <nav className="hidden md:flex space-x-6">
            <Link href="/" className="font-medium">
              Home
            </Link>
            <Link href="/lessons" className="font-medium text-blue-600">
              Lessons
            </Link>
            <Link href="/practice" className="font-medium">
              Practice
            </Link>
            <Link href="/quizzes" className="font-medium">
              Quizzes
            </Link>
            <Link href="/resources" className="font-medium">
              Resources
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-12 bg-blue-600 text-white">
          <div className="container mx-auto px-4">
            <motion.h2
              className="text-4xl font-bold mb-4"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Introduction to Algebra
            </motion.h2>
            <motion.p
              className="text-xl mb-0 max-w-2xl"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              Learn the fundamental concepts of algebra and its applications.
            </motion.p>
          </div>
        </section>

        <section className="py-12 container mx-auto px-4">
          <motion.div
            className="max-w-3xl mx-auto bg-white p-8 rounded-lg shadow-md"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h3 className="text-2xl font-bold mb-4">What is Algebra?</h3>
            <p className="mb-4">
              Algebra is a branch of mathematics that uses letters and symbols to represent numbers and quantities in
              formulas and equations. It's a fundamental tool for solving problems in mathematics, science, and everyday
              life.
            </p>
            <h3 className="text-2xl font-bold mb-4">Key Concepts</h3>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>Variables: Letters used to represent unknown numbers</li>
              <li>Expressions: Combinations of variables, numbers, and operations</li>
              <li>Equations: Statements that show two expressions are equal</li>
              <li>Functions: Rules that relate one quantity to another</li>
            </ul>
            <h3 className="text-2xl font-bold mb-4">Example</h3>
            <p className="mb-4">
              Let's look at a simple algebraic equation: <code>x + 5 = 12</code>
            </p>
            <p className="mb-4">
              Here, <code>x</code> is a variable representing an unknown number. We can solve this equation to find the
              value of <code>x</code>:
            </p>
            <pre className="bg-gray-100 p-4 rounded-md mb-4">x + 5 = 12 x = 12 - 5 x = 7</pre>
            <p className="mb-4">
              So, the solution to this equation is <code>x = 7</code>. We can verify this by substituting 7 back into
              the original equation: <code>7 + 5 = 12</code>, which is true.
            </p>
          </motion.div>
        </section>

        <section className="py-6 container mx-auto px-4">
          <div className="max-w-3xl mx-auto flex justify-between">
            <Button variant="outline" asChild>
              <Link href="/lessons/algebra">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Algebra Lessons
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/lessons/algebra/expressions">
                Next: Algebraic Expressions
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </section>
      </main>

      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p>© {new Date().getFullYear()} MathLearningPortal. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

