import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Calculator, BookOpen, Award, ChevronRight, Gamepad2 } from "lucide-react"
import SecretTrigger from "@/components/secret-trigger"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Calculator className="h-6 w-6 text-blue-600" />
            <h1 className="text-xl font-bold">MathLearningPortal</h1>
          </div>
          <nav className="hidden md:flex space-x-6">
            <Link href="/" className="font-medium">
              Home
            </Link>
            <Link href="/lessons" className="font-medium">
              Lessons
            </Link>
            <Link href="/practice" className="font-medium">
              Practice
            </Link>
            <Link href="/quizzes" className="font-medium">
              Quizzes
            </Link>
            <Link href="/resources" className="font-medium">
              Resources
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-12 bg-blue-50">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Improve Your Math Skills Today</h2>
            <p className="text-lg mb-8 max-w-2xl mx-auto">
              Interactive lessons, practice problems, and resources to help you excel in mathematics.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700" asChild>
                <Link href="/lessons">
                  Start Learning
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/practice">Practice Now</Link>
              </Button>
            </div>
          </div>
        </section>

        <section className="py-16 container mx-auto px-4">
          <h2 className="text-2xl font-bold text-center mb-12">Why Choose Our Platform?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm border text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Comprehensive Lessons</h3>
              <p className="text-gray-600">
                From basic arithmetic to advanced calculus, our lessons cover all math topics.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm border text-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Calculator className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Interactive Practice</h3>
              <p className="text-gray-600">
                Solve problems at your own pace with instant feedback and detailed solutions.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm border text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="h-6 w-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Track Your Progress</h3>
              <p className="text-gray-600">Monitor your improvement with detailed statistics and achievement badges.</p>
            </div>
          </div>
        </section>

        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl font-bold text-center mb-8">Featured Math Topics</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { name: "Algebra", link: "/lessons/algebra" },
                { name: "Geometry", link: "/lessons/geometry" },
                { name: "Calculus", link: "/lessons/calculus" },
                { name: "Statistics", link: "/lessons/statistics" },
                { name: "Trigonometry", link: "/lessons/trigonometry" },
                { name: "Probability", link: "/lessons/probability" },
                { name: "Number Theory", link: "/lessons/number-theory" },
                { name: "Discrete Math", link: "/lessons/discrete-math" },
              ].map((topic) => (
                <Link
                  key={topic.name}
                  href={topic.link}
                  className="bg-white p-4 rounded border hover:shadow-md transition-shadow"
                >
                  <h3 className="font-medium">{topic.name}</h3>
                </Link>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between">
            <div className="mb-6 md:mb-0">
              <div className="flex items-center space-x-2 mb-4">
                <Calculator className="h-6 w-6" />
                <h2 className="text-xl font-bold">MathLearningPortal</h2>
              </div>
              <p className="text-gray-400 max-w-md">
                Helping students master mathematics through interactive learning and practice.
              </p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
              <div>
                <h3 className="text-lg font-semibold mb-4">Learn</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/lessons" className="text-gray-400 hover:text-white">
                      Lessons
                    </Link>
                  </li>
                  <li>
                    <Link href="/practice" className="text-gray-400 hover:text-white">
                      Practice
                    </Link>
                  </li>
                  <li>
                    <Link href="/quizzes" className="text-gray-400 hover:text-white">
                      Quizzes
                    </Link>
                  </li>
                  <li>
                    <Link href="/resources" className="text-gray-400 hover:text-white">
                      Resources
                    </Link>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">About</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/about" className="text-gray-400 hover:text-white">
                      Our Mission
                    </Link>
                  </li>
                  <li>
                    <Link href="/team" className="text-gray-400 hover:text-white">
                      Team
                    </Link>
                  </li>
                  <li>
                    <Link href="/contact" className="text-gray-400 hover:text-white">
                      Contact
                    </Link>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">Legal</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/terms" className="text-gray-400 hover:text-white">
                      Terms
                    </Link>
                  </li>
                  <li>
                    <Link href="/privacy" className="text-gray-400 hover:text-white">
                      Privacy
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-700 text-center text-gray-400">
            <p>© {new Date().getFullYear()} MathLearningPortal. All rights reserved.</p>
            <div className="mt-2 flex justify-center">
              <Link href="/fun" className="text-gray-500 hover:text-gray-300 text-xs flex items-center">
                <Gamepad2 className="h-3 w-3 mr-1" />
                <span>Brain Breaks</span>
              </Link>
            </div>
          </div>
        </div>
      </footer>
      <SecretTrigger />
    </div>
  )
}

