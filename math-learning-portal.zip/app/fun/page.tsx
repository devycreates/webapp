"use client"

import { useState } from "react"
import Link from "next/link"
import { Input } from "@/components/ui/input"
import { Search, ArrowLeft, Gamepad2 } from "lucide-react"

// Game data
const games = [
  {
    id: 1,
    title: "2048",
    description: "Merge tiles to reach 2048",
    url: "https://play2048.co/",
  },
  {
    id: 2,
    title: "Tetris",
    description: "Classic block stacking game",
    url: "https://tetris.com/play-tetris",
  },
  {
    id: 3,
    title: "Snake",
    description: "Grow your snake by eating food",
    url: "https://playsnake.org/",
  },
  {
    id: 4,
    title: "Sudoku",
    description: "Fill in the numbers puzzle",
    url: "https://sudoku.com/",
  },
  {
    id: 5,
    title: "Chess",
    description: "Play chess online",
    url: "https://www.chess.com/play/computer",
  },
  {
    id: 6,
    title: "Minesweeper",
    description: "Clear the minefield",
    url: "https://minesweeper.online/",
  },
]

export default function GamesPage() {
  const [searchTerm, setSearchTerm] = useState("")

  // Filter games based on search term
  const filteredGames = games.filter((game) => game.title.toLowerCase().includes(searchTerm.toLowerCase()))

  // Function to open game in about:blank
  const openGameInBlank = (gameUrl: string) => {
    const newWindow = window.open("about:blank", "_blank")

    if (newWindow) {
      newWindow.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>Math Exercise</title>
            <style>
              body, html { margin: 0; padding: 0; height: 100%; overflow: hidden; }
              iframe { width: 100%; height: 100%; border: none; }
            </style>
          </head>
          <body>
            <iframe src="${gameUrl}" allowfullscreen></iframe>
          </body>
        </html>
      `)
      newWindow.document.close()
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Gamepad2 className="h-6 w-6 text-blue-600" />
            <h1 className="text-xl font-bold">Brain Breaks</h1>
          </div>
          <Link href="/" className="flex items-center text-blue-600 hover:text-blue-800">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to Math
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-sm border p-6 mb-8">
          <h2 className="text-2xl font-bold mb-4">Educational Game Collection</h2>
          <p className="text-gray-600 mb-6">
            Take a short break with these brain games! They help improve focus and cognitive skills.
          </p>

          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              type="text"
              placeholder="Search games..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredGames.map((game) => (
              <div
                key={game.id}
                className="border rounded-lg overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => openGameInBlank(game.url)}
              >
                <img
                  src={`/placeholder.svg?height=150&width=250&text=${game.title}`}
                  alt={game.title}
                  className="w-full h-40 object-cover"
                />
                <div className="p-4">
                  <h3 className="font-bold text-lg mb-1">{game.title}</h3>
                  <p className="text-gray-600 text-sm">{game.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      <footer className="bg-white border-t py-6">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>© {new Date().getFullYear()} MathLearningPortal. All rights reserved.</p>
          <p className="text-sm mt-2">These brain breaks help improve focus and learning retention.</p>
        </div>
      </footer>
    </div>
  )
}

