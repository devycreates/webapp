"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Calculator, Trophy, Star } from "lucide-react"
import confetti from "canvas-confetti"

// Function to generate random math problems
const generateProblem = () => {
  const operations = ["+", "-", "*", "/"]
  const operation = operations[Math.floor(Math.random() * operations.length)]
  let num1, num2

  switch (operation) {
    case "+":
    case "-":
      num1 = Math.floor(Math.random() * 100)
      num2 = Math.floor(Math.random() * 100)
      break
    case "*":
      num1 = Math.floor(Math.random() * 12)
      num2 = Math.floor(Math.random() * 12)
      break
    case "/":
      num2 = Math.floor(Math.random() * 11) + 1 // Divisor between 1 and 12
      num1 = num2 * Math.floor(Math.random() * 12) // Ensure division results in whole number
      break
  }

  const question = `${num1} ${operation} ${num2}`
  const answer = eval(question).toString() // Evaluate the expression

  return { question, answer }
}

export default function ArenaPage() {
  const [problem, setProblem] = useState({ question: "", answer: "" })
  const [userAnswer, setUserAnswer] = useState("")
  const [score, setScore] = useState(0)
  const [streak, setStreak] = useState(0)
  const [highScore, setHighScore] = useState(0)

  useEffect(() => {
    setProblem(generateProblem())
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (userAnswer === problem.answer) {
      setScore(score + 1)
      setStreak(streak + 1)
      if (streak + 1 > highScore) {
        setHighScore(streak + 1)
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
        })
      }
      setProblem(generateProblem())
    } else {
      setStreak(0)
    }
    setUserAnswer("")
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Calculator className="h-6 w-6 text-blue-600" />
            <h1 className="text-xl font-bold">MathLearningPortal Arena</h1>
          </div>
          <nav className="hidden md:flex space-x-6">
            <Link href="/" className="font-medium">
              Home
            </Link>
            <Link href="/lessons" className="font-medium">
              Lessons
            </Link>
            <Link href="/practice" className="font-medium text-blue-600">
              Practice
            </Link>
            <Link href="/quizzes" className="font-medium">
              Quizzes
            </Link>
            <Link href="/resources" className="font-medium">
              Resources
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-12 bg-blue-600 text-white">
          <div className="container mx-auto px-4">
            <motion.h2
              className="text-4xl font-bold mb-4"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              MathLearningPortal Arena
            </motion.h2>
            <motion.p
              className="text-xl mb-0 max-w-2xl"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              Test your math skills with infinite challenges and earn rewards!
            </motion.p>
          </div>
        </section>

        <section className="py-12 container mx-auto px-4">
          <motion.div
            className="max-w-md mx-auto bg-white p-8 rounded-lg shadow-md"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex justify-between items-center mb-6">
              <div className="flex items-center">
                <Trophy className="h-6 w-6 text-yellow-500 mr-2" />
                <span className="text-xl font-bold">Score: {score}</span>
              </div>
              <div className="flex items-center">
                <Star className="h-6 w-6 text-blue-500 mr-2" />
                <span className="text-xl font-bold">Streak: {streak}</span>
              </div>
            </div>
            <AnimatePresence mode="wait">
              <motion.div
                key={problem.question}
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                transition={{ duration: 0.3 }}
              >
                <h3 className="text-2xl font-bold mb-4 text-center">{problem.question} = ?</h3>
              </motion.div>
            </AnimatePresence>
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                type="text"
                value={userAnswer}
                onChange={(e) => setUserAnswer(e.target.value)}
                placeholder="Enter your answer"
                className="text-center text-xl"
              />
              <Button type="submit" className="w-full">
                Submit Answer
              </Button>
            </form>
            <div className="mt-6 text-center">
              <p className="text-sm text-gray-600">High Score: {highScore}</p>
            </div>
          </motion.div>
        </section>
      </main>

      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p>© {new Date().getFullYear()} MathLearningPortal. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

