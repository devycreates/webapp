"use client"

import { useRouter } from "next/navigation"
import { useEffect } from "react"

export default function SecretTrigger() {
  const router = useRouter()

  useEffect(() => {
    let lastGKeyTime = 0

    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key.toLowerCase() === "g") {
        const now = Date.now()
        if (now - lastGKeyTime < 500) {
          // Double press within 500ms
          router.push("/fun")
        }
        lastGKeyTime = now
      }
    }

    window.addEventListener("keydown", handleKeyPress)
    return () => window.removeEventListener("keydown", handleKeyPress)
  }, [router])

  return null
}

